/**
 * Terrain management for Dimensional Weather
 */

import { updateSceneFlag } from "./utils.js";

export class DimensionalWeatherTerrain {
  constructor(parent) {
    this.parent = parent;
  }

  /**
   * Sets the current terrain
   * @param {string} terrainKey - The terrain key to set
   */
  async setTerrain(terrainKey) {
    const settings = game.settings.get("dimensional-weather", "settings");
    if (!this.parent.settings.settingsData?.terrains[terrainKey]) {
      console.warn(`Dimensional Weather | Invalid terrain: ${terrainKey}`);
      return;
    }

    settings.terrain = terrainKey;
    await game.settings.set("dimensional-weather", "settings", settings);

    const scene = game.scenes.viewed;
    if (scene?.id) {
      const savedState =
        scene.getFlag("dimensional-weather", "weatherState") || {};
      await updateSceneFlag(scene, "dimensional-weather", "weatherState", {
        ...savedState,
        terrain: terrainKey,
      });
    }

    await this.parent.weather.initWeather();
  }

  /**
   * Gets the current terrain name
   * @returns {string} The current terrain name
   */
  getCurrentTerrain() {
    const settings = game.settings.get("dimensional-weather", "settings");
    const terrain = this.parent.settings.settingsData?.terrains[
      settings.terrain
    ];
    return terrain?.name || "Unknown Terrain";
  }

  /**
   * Gets all available terrain options
   * @returns {Array<{key: string, name: string}>} Array of terrain options
   */
  getTerrainOptions() {
    const terrains = this.parent.settings.settingsData?.terrains || {};
    return Object.entries(terrains).map(([key, terrain]) => ({
      key,
      name: terrain.name,
    }));
  }

  /**
   * Validates a terrain key
   * @param {string} terrainKey - The terrain key to validate
   * @returns {boolean} Whether the terrain key is valid
   */
  isValidTerrain(terrainKey) {
    return !!this.parent.settings.settingsData?.terrains[terrainKey];
  }
}
