/**
 * Calendar integration for Dimensional Weather
 */

export class DimensionalWeatherCalendar {
  constructor(parent) {
    this.parent = parent;
  }

  /**
   * Gets the current season from Simple Calendar
   * @returns {string|null} The current season name or null if not available
   */
  getCurrentSeason() {
    if (
      !game.settings.get("dimensional-weather", "useSimpleCalendar") ||
      !SimpleCalendar?.api
    ) {
      return null;
    }

    const currentSeason = SimpleCalendar.api.getCurrentSeason();
    return currentSeason?.name || null;
  }

  /**
   * Gets the current date and time from Simple Calendar
   * @returns {Object|null} The current date and time or null if not available
   */
  getCurrentDateTime() {
    if (
      !game.settings.get("dimensional-weather", "useSimpleCalendar") ||
      !SimpleCalendar?.api
    ) {
      return null;
    }

    return SimpleCalendar.api.currentDateTimeDisplay();
  }

  /**
   * Displays calendar information
   */
  async displayCalendarInfo() {
    if (!SimpleCalendar?.api) {
      ui.notifications.warn("Simple Calendar module is not active.");
      return;
    }

    const dt = this.getCurrentDateTime();
    if (!dt) return;

    const calendarInfo = `
            <div class="weather-calendar">
                <h3>Calendar Information</h3>
                <p>Date: ${dt.day}${dt.daySuffix} ${dt.monthName}</p>
                <p>Time: ${dt.time}</p>
            </div>
        `;

    ChatMessage.create({
      content: calendarInfo,
      speaker: { alias: "Dimensional Weather" },
    });
  }

  /**
   * Registers hooks for calendar integration
   */
  registerHooks() {
    if (!game.settings.get("dimensional-weather", "useSimpleCalendar")) return;

    Hooks.on("simple-calendar-day-change", async () => {
      await this.parent.weather.updateWeather(true);
    });

    Hooks.on("simple-calendar-month-change", async () => {
      await this.parent.weather.updateWeather(true);
    });
  }
}
