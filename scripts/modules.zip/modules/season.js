/**
 * Season management for Dimensional Weather
 */

import { updateSceneFlag } from "./utils.js";

export class DimensionalWeatherSeason {
  constructor(parent) {
    this.parent = parent;
  }

  /**
   * Sets the current season
   * @param {string} seasonKey - The season key to set
   */
  async setSeason(seasonKey) {
    if (!this.parent.settings.settingsData?.seasons[seasonKey]) {
      console.warn(`Dimensional Weather | Invalid season: ${seasonKey}`);
      return;
    }

    const settings = game.settings.get("dimensional-weather", "settings");
    settings.season = seasonKey;
    await game.settings.set("dimensional-weather", "settings", settings);

    const scene = game.scenes.viewed;
    if (scene?.id) {
      const savedState =
        scene.getFlag("dimensional-weather", "weatherState") || {};
      await updateSceneFlag(scene, "dimensional-weather", "weatherState", {
        ...savedState,
        season: seasonKey,
      });
    }

    await this.parent.weather.initWeather();
  }

  /**
   * Gets the current season name
   * @returns {string} The current season name
   */
  getCurrentSeason() {
    if (game.settings.get("dimensional-weather", "useSimpleCalendar")) {
      const calendarSeason = this.parent.calendar.getCurrentSeason();
      if (calendarSeason) return calendarSeason;
    }

    const settings = game.settings.get("dimensional-weather", "settings");
    const season = this.parent.settings.settingsData?.seasons[settings.season];
    return season?.name || "Unknown Season";
  }

  /**
   * Gets all available season options
   * @returns {Array<{key: string, name: string}>} Array of season options
   */
  getSeasonOptions() {
    const seasons = this.parent.settings.settingsData?.seasons || {};
    return Object.entries(seasons).map(([key, season]) => ({
      key,
      name: season.name,
    }));
  }

  /**
   * Validates a season key
   * @param {string} seasonKey - The season key to validate
   * @returns {boolean} Whether the season key is valid
   */
  isValidSeason(seasonKey) {
    return !!this.parent.settings.settingsData?.seasons[seasonKey];
  }

  /**
   * Gets season modifiers for weather calculations
   * @param {string} seasonKey - The season key
   * @returns {Object} The season modifiers
   */
  getSeasonModifiers(seasonKey) {
    const season = this.parent.settings.settingsData?.seasons[seasonKey];
    if (!season) return null;

    return {
      temperatureModifier: season.temperatureModifier || 0,
      windModifier: season.windModifier || 0,
      precipitationModifier: season.precipitationModifier || 0,
      humidityModifier: season.humidityModifier || 0,
    };
  }
}
