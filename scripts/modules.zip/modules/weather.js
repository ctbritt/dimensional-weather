/**
 * Core weather functionality for Dimensional Weather
 */

import { safeFetch, updateSceneFlag, randomRange, clamp } from "./utils.js";

export class DimensionalWeatherCore {
  constructor(parent) {
    this.parent = parent;
    this.temperature = 20;
    this.wind = 0;
    this.precipitation = 0;
    this.humidity = 50;
    this.variability = 5;
  }

  /**
   * Loads settings and initializes weather state
   */
  async loadSettings() {
    try {
      const settings = game.settings.get("dimensional-weather", "settings");
      const selectedSetting =
        game.settings.get("dimensional-weather", "campaignSetting") ||
        "default";

      const settingInfo = this.parent.settings.settingsIndex?.campaignSettings.find(
        (s) => s.id === selectedSetting
      );

      if (!settingInfo) {
        throw new Error(`Invalid campaign setting: ${selectedSetting}`);
      }

      this.parent.settings.settingsData = await safeFetch(
        `/modules/dimensional-weather/campaign_settings/${settingInfo.path}`
      );

      // Initialize defaults if not set
      if (!settings.terrain || !settings.season) {
        settings.terrain = Object.keys(
          this.parent.settings.settingsData.terrains
        )[0];
        settings.season = Object.keys(
          this.parent.settings.settingsData.seasons
        )[0];
        await game.settings.set("dimensional-weather", "settings", settings);
      }
    } catch (error) {
      console.error("Dimensional Weather | Failed to load settings:", error);
      ui.notifications.error(
        "Failed to load weather settings. Check the console for details."
      );
    }
  }

  /**
   * Initializes weather for the current scene
   */
  async initWeather() {
    const scene = game.scenes.viewed;
    if (!scene?.id) return;

    const savedState = scene.getFlag("dimensional-weather", "weatherState");
    if (savedState) {
      this.temperature = savedState.temperature;
      this.wind = savedState.wind;
      this.precipitation = savedState.precipitation;
      this.humidity = savedState.humidity;
    } else {
      await this.generateNewWeather();
    }
  }

  /**
   * Generates new weather conditions
   */
  async generateNewWeather() {
    const settings = game.settings.get("dimensional-weather", "settings");
    const terrain = this.parent.settings.settingsData.terrains[
      settings.terrain
    ];
    const season = this.parent.settings.settingsData.seasons[settings.season];

    // Generate base values
    this.temperature = randomRange(
      terrain.temperature.min,
      terrain.temperature.max
    );
    this.wind = randomRange(0, 10);
    this.precipitation = randomRange(0, 10);
    this.humidity = randomRange(40, 80);

    // Apply season modifiers
    this.temperature += season.temperatureModifier;
    this.wind += season.windModifier;
    this.precipitation += season.precipitationModifier;
    this.humidity += season.humidityModifier;

    // Apply variability
    const variability = this.variability / 10;
    this.temperature = clamp(
      this.temperature + randomRange(-10, 10) * variability,
      terrain.temperature.min,
      terrain.temperature.max
    );
    this.wind = clamp(this.wind + randomRange(-2, 2) * variability, 0, 10);
    this.precipitation = clamp(
      this.precipitation + randomRange(-2, 2) * variability,
      0,
      10
    );
    this.humidity = clamp(
      this.humidity + randomRange(-10, 10) * variability,
      0,
      100
    );

    // Save state to scene
    const scene = game.scenes.viewed;
    if (scene?.id) {
      await updateSceneFlag(scene, "dimensional-weather", "weatherState", {
        temperature: this.temperature,
        wind: this.wind,
        precipitation: this.precipitation,
        humidity: this.humidity,
        terrain: settings.terrain,
        season: settings.season,
      });
    }
  }

  /**
   * Updates weather conditions
   * @param {boolean} force - Whether to force an update
   */
  async updateWeather(force = false) {
    if (!force && !game.settings.get("dimensional-weather", "autoUpdate"))
      return;

    const scene = game.scenes.viewed;
    if (!scene?.id) return;

    await this.generateNewWeather();
    await this.displayWeatherReport();
  }

  /**
   * Displays the current weather report
   */
  async displayWeatherReport() {
    const settings = game.settings.get("dimensional-weather", "settings");
    const terrain = this.parent.settings.settingsData.terrains[
      settings.terrain
    ];
    const season = this.parent.settings.settingsData.seasons[settings.season];

    const report = `
            <div class="weather-report">
                <h3>Current Weather</h3>
                <p>Temperature: ${this.temperature}°C</p>
                <p>Wind: ${this.wind}/10</p>
                <p>Precipitation: ${this.precipitation}/10</p>
                <p>Humidity: ${this.humidity}%</p>
                <p>Terrain: ${terrain.name}</p>
                <p>Season: ${season.name}</p>
            </div>
        `;

    ChatMessage.create({
      content: report,
      speaker: { alias: "Dimensional Weather" },
    });
  }
}
