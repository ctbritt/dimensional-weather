/**
 * Utility functions for Dimensional Weather
 */

/**
 * Safely fetches JSON data from a URL
 * @param {string} url - The URL to fetch from
 * @returns {Promise<Object>} The fetched data
 */
export async function safeFetch(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error(`Dimensional Weather | Failed to fetch ${url}:`, error);
    return null;
  }
}

/**
 * Updates a scene flag with new data
 * @param {Scene} scene - The scene to update
 * @param {string} module - The module name
 * @param {string} key - The flag key
 * @param {Object} value - The new value
 */
export async function updateSceneFlag(scene, module, key, value) {
  try {
    await scene.setFlag(module, key, value);
  } catch (error) {
    console.error(`Dimensional Weather | Failed to update scene flag:`, error);
  }
}

/**
 * Formats a display name by capitalizing words and replacing underscores with spaces
 * @param {string} name - The name to format
 * @returns {string} The formatted name
 */
export function formatDisplayName(name) {
  return name
    .split(/[-_]/)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

/**
 * Generates a random number between min and max (inclusive)
 * @param {number} min - The minimum value
 * @param {number} max - The maximum value
 * @returns {number} The random number
 */
export function randomRange(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Clamps a number between min and max
 * @param {number} value - The value to clamp
 * @param {number} min - The minimum value
 * @param {number} max - The maximum value
 * @returns {number} The clamped value
 */
export function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}
