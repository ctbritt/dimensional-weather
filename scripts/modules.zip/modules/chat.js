/**
 * Chat commands for Dimensional Weather
 */

import { formatDisplayName } from "./utils.js";

export class DimensionalWeatherChat {
  constructor(parent) {
    this.parent = parent;
  }

  /**
   * Registers chat commands
   * @param {Object} commands - The chat commands object
   */
  registerCommands(commands) {
    // Check if we're using Chat Commander
    const isChatCommander = game.modules.get("_chatcommands")?.active;

    if (isChatCommander) {
      // Register with Chat Commander
      commands.register({
        name: "weather",
        module: "dimensional-weather",
        description: "Display current weather conditions",
        usage: "/weather [subcommand] [args...]",
        callback: async (args) => {
          return this.handleWeatherCommand(args);
        },
      });

      commands.register({
        name: "date",
        module: "dimensional-weather",
        description: "Display calendar information (GM only)",
        usage: "/date",
        callback: async () => {
          return this.handleDateCommand();
        },
      });
    } else {
      // Register with Foundry's native chat system
      commands.registerCommand("weather", {
        description: "Display current weather conditions",
        usage: "/weather [subcommand] [args...]",
        callback: async (args) => {
          return this.handleWeatherCommand(args);
        },
      });

      commands.registerCommand("date", {
        description: "Display calendar information (GM only)",
        usage: "/date",
        callback: async () => {
          return this.handleDateCommand();
        },
      });
    }
  }

  /**
   * Handles the weather command
   * @param {Array} args - Command arguments
   */
  async handleWeatherCommand(args) {
    try {
      if (!args.length) {
        await this.parent.weather.displayWeatherReport();
        return;
      }

      const subcommand = args[0]?.toLowerCase();

      // Handle version command first since it's available to all users
      if (subcommand === "version" || subcommand === "v") {
        if (!this.parent.settings.settingsData) {
          return {
            content: "Weather system not initialized or settings not loaded.",
            speaker: { alias: "Dimensional Weather" },
          };
        }
        return {
          content: `Weather System Info:<br>
                   Name: ${this.parent.settings.settingsData.name}<br>
                   Version: ${this.parent.settings.settingsData.version}<br>
                   Description: ${this.parent.settings.settingsData.description}`,
          speaker: { alias: "Dimensional Weather" },
        };
      }

      // Handle setting command - available to GMs only
      if (subcommand === "campaign") {
        if (!game.user.isGM) {
          ui.notifications.warn("Only the GM can change campaign settings.");
          return;
        }

        if (args.length < 2) {
          ui.notifications.warn(
            "Please specify a campaign setting. Use /weather help for available options."
          );
          return;
        }

        const settingId = args[1].toLowerCase();
        const setting = this.parent.settings.settingsIndex.campaignSettings.find(
          (s) => s.id.toLowerCase() === settingId
        );

        if (!setting) {
          ui.notifications.warn(
            `Invalid campaign setting: ${settingId}. Use /weather help for available options.`
          );
          return;
        }

        // Set the campaign setting
        await game.settings.set(
          "dimensional-weather",
          "campaignSetting",
          setting.id
        );

        // Load the new settings
        await this.parent.settings.loadCampaignSettings();

        // Get the first available terrain and season
        const defaultTerrain = Object.keys(
          this.parent.settings.settingsData.terrains
        )[0];
        const defaultSeason = Object.keys(
          this.parent.settings.settingsData.seasons
        )[0];

        if (!defaultTerrain || !defaultSeason) {
          ui.notifications.error(
            "Failed to load default terrain or season from new settings."
          );
          return;
        }

        // Update the settings with new choices and defaults
        await game.settings.set(
          "dimensional-weather",
          "terrain",
          defaultTerrain
        );
        await game.settings.set("dimensional-weather", "season", defaultSeason);

        // Update the scene flags with the new terrain and season
        const scene = game.scenes.viewed;
        if (scene?.id) {
          const savedState =
            scene.getFlag("dimensional-weather", "weatherState") || {};
          await scene.setFlag("dimensional-weather", "weatherState", {
            ...savedState,
            terrain: defaultTerrain,
            season: defaultSeason,
          });
        }

        // Format the terrain name with all words capitalized
        const formattedTerrain = defaultTerrain
          .replace(/([A-Z])/g, " $1")
          .trim()
          .split(" ")
          .map(
            (word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
          )
          .join(" ");

        // Format the season name
        const formattedSeason = this.parent.settings.settingsData.seasons[
          defaultSeason
        ].name;

        return {
          content: `Campaign setting changed to ${setting.name}. Terrain set to ${formattedTerrain} and season to ${formattedSeason}.`,
          speaker: { alias: "Dimensional Weather" },
          whisper: [game.user.id],
        };
      }

      // Only allow GMs to use other subcommands
      if (!game.user.isGM) {
        ui.notifications.warn("Only the GM can modify weather conditions.");
        await this.parent.weather.displayWeatherReport();
        return;
      }

      switch (subcommand) {
        case "terrain":
          if (args.length < 2) {
            ui.notifications.warn(
              "Please specify a terrain type. Use /weather help for available options."
            );
            return;
          }
          // Convert the terrain name to camelCase format
          const terrain = args
            .slice(1)
            .join(" ")
            .toLowerCase()
            .replace(/\s+(\w)/g, (match, letter) => letter.toUpperCase())
            .replace(/^(\w)/, (match, letter) => letter.toLowerCase());

          if (
            Object.keys(this.parent.settings.settingsData.terrains).includes(
              terrain
            )
          ) {
            await this.parent.terrain.setTerrain(terrain);
            return {
              content: `Terrain has been set to ${terrain
                .replace(/([A-Z])/g, " $1")
                .trim()}`,
              speaker: { alias: "Dimensional Weather" },
              whisper: [game.user.id],
            };
          } else {
            ui.notifications.warn(
              `Invalid terrain type: ${terrain}. Use /weather help for available options.`
            );
          }
          break;

        case "season":
          if (args.length < 2) {
            ui.notifications.warn(
              "Please specify a season. Use /weather season help for available options."
            );
            return;
          }

          // Check if Simple Calendar integration is enabled
          const settings = game.settings.get("dimensional-weather", "settings");
          if (settings.useSimpleCalendar) {
            return {
              content:
                "Turn off Simple Calendar integration to manually change seasons.",
              speaker: { alias: "Dimensional Weather" },
              whisper: [game.user.id],
            };
          }

          // Join all arguments after "season" to handle multi-word season names
          const seasonName = args.slice(1).join(" ").toLowerCase();
          const seasonKey = Object.entries(
            this.parent.settings.settingsData.seasons
          ).find(([_, s]) => s.name.toLowerCase() === seasonName)?.[0];
          if (!seasonKey) {
            ui.notifications.warn(
              `Invalid season: ${seasonName}. Use /weather season help for available options.`
            );
            return;
          }
          await this.parent.season.setSeason(seasonKey);
          return this.parent.weather.getWeatherDescription();

        case "update":
          await this.parent.weather.updateWeather(true);
          break;

        case "random":
          if (args.length < 2) {
            ui.notifications.warn("Please specify a value between 0 and 10.");
            return;
          }
          const value = parseInt(args[1]);
          if (isNaN(value) || value < 0 || value > 10) {
            ui.notifications.warn(
              "Variability must be a number between 0 and 10."
            );
            return;
          }
          const currentSettings = game.settings.get(
            "dimensional-weather",
            "settings"
          );
          currentSettings.variability = value;
          await game.settings.set(
            "dimensional-weather",
            "settings",
            currentSettings
          );
          this.parent.weather.variability = value;
          ui.notifications.info(`Weather variability set to ${value}`);
          break;

        case "stats":
          const scene = game.scenes.viewed;
          const savedState = scene?.id
            ? scene.getFlag("dimensional-weather", "weatherState")
            : null;

          const stats = {
            temperature:
              savedState?.temperature ?? this.parent.weather.temperature,
            wind: savedState?.wind ?? this.parent.weather.wind,
            precipitation:
              savedState?.precipitation ?? this.parent.weather.precipitation,
            humidity: savedState?.humidity ?? this.parent.weather.humidity,
            variability: this.parent.weather.variability,
            terrain:
              savedState?.terrain ??
              game.settings.get("dimensional-weather", "terrain"),
            season: savedState?.season ?? this.parent.season.getCurrentSeason(),
            scene: scene?.name ?? "No active scene",
          };

          return {
            content: `Weather Statistics (GM Only):\n${JSON.stringify(
              stats,
              null,
              2
            )}`,
            speaker: { alias: "Dimensional Weather" },
            whisper: [game.user.id],
          };

        case "help":
          return this.displayHelp();

        case "terrains":
          const availableTerrains = Object.entries(
            this.parent.settings.settingsData.terrains
          )
            .map(([key, terrain]) => `${terrain.name} (${key})`)
            .join("\n");
          return {
            content: `Available Terrains for ${this.parent.settings.settingsData.name}:\n${availableTerrains}`,
            speaker: { alias: "Dimensional Weather" },
          };

        default:
          return "Invalid subcommand. Use /weather help for available options.";
      }
    } catch (error) {
      console.error("Weather command error:", error);
      ui.notifications.error(
        "An error occurred while processing the weather command."
      );
    }
  }

  /**
   * Handles the date command
   */
  async handleDateCommand() {
    try {
      const calendarInfo = await this.parent.calendar.displayCalendarInfo();
      return {
        content: calendarInfo,
        speaker: { alias: "Dimensional Weather" },
        whisper: [game.user.id],
      };
    } catch (error) {
      console.error("Date command error:", error);
      ui.notifications.error(
        "An error occurred while displaying calendar information."
      );
    }
  }

  /**
   * Displays help information
   */
  displayHelp() {
    const help = `
            <div class="weather-help">
                <h3>Weather Commands</h3>
                <p><strong>/weather campaign [name]</strong> - Set the campaign setting</p>
                <p><strong>/weather terrain [type]</strong> - Set the terrain type</p>
                <p><strong>/weather season [name]</strong> - Set the current season</p>
                <p><strong>/weather update</strong> - Force update weather conditions</p>
                <p><strong>/weather random [0-10]</strong> - Set weather variability</p>
                <p><strong>/weather stats</strong> - Display current weather statistics</p>
                <p><strong>/weather calendar</strong> - Display calendar information</p>
            </div>
        `;

    ChatMessage.create({
      content: help,
      speaker: { alias: "Dimensional Weather" },
    });
  }
}
