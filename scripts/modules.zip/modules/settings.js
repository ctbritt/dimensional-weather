/**
 * Settings management for Dimensional Weather
 */

import { safeFetch } from "./utils.js";

export class DimensionalWeatherSettings {
  constructor() {
    this.settingsData = null;
    this.settingsIndex = null;
  }

  /**
   * Registers all module settings
   */
  registerSettings() {
    // Register campaign setting
    game.settings.register("dimensional-weather", "campaignSetting", {
      name: "Campaign Setting",
      hint: "Select the campaign setting to use for weather rules",
      scope: "world",
      config: true,
      type: String,
      choices: {},
      default: "default",
      onChange: async (value) => {
        await this.handleCampaignChange(value);
      },
    });

    // Register weather settings
    game.settings.register("dimensional-weather", "settings", {
      name: "Weather Settings",
      scope: "world",
      config: false,
      type: Object,
      default: {
        terrain: "temperate",
        season: "spring",
        variability: 5,
        useSimpleCalendar: false,
        autoUpdate: true,
      },
    });

    // Register campaign settings cache
    game.settings.register("dimensional-weather", "campaignSettings", {
      name: "Campaign Settings Cache",
      scope: "world",
      config: false,
      type: Object,
      default: {},
    });
  }

  /**
   * Loads campaign settings from the index file
   */
  async loadCampaignSettings() {
    try {
      const index = await safeFetch(
        "/modules/dimensional-weather/campaign_settings/index.json"
      );

      // Update campaign setting choices
      const choices = {};
      index.campaignSettings.forEach((setting) => {
        choices[setting.id] = setting.name;
      });

      // Update the choices in the campaign setting
      const setting = game.settings.get(
        "dimensional-weather",
        "campaignSetting"
      );
      game.settings.settings.get(
        "dimensional-weather.campaignSetting"
      ).choices = choices;

      // Store the index
      this.settingsIndex = index;

      // Load the initial campaign settings
      const campaignId = setting || "default";
      await this.handleCampaignChange(campaignId);
    } catch (error) {
      console.error(
        "Dimensional Weather | Failed to load campaign settings:",
        error
      );
      ui.notifications.error(
        "Failed to load campaign settings. Check the console for details."
      );
    }
  }

  /**
   * Handles campaign setting changes
   * @param {string} value - The new campaign setting value
   */
  async handleCampaignChange(value) {
    const settingsData = await this.fetchSettingsData(value);
    if (!settingsData) {
      console.warn(
        `Dimensional Weather | Failed to load settings for ${value}`
      );
      return;
    }

    this.settingsData = settingsData;

    const defaultTerrain = Object.keys(settingsData.terrains)[0];
    const defaultSeason = Object.keys(settingsData.seasons)[0];

    const settings = game.settings.get("dimensional-weather", "settings");
    settings.terrain = defaultTerrain;
    settings.season = defaultSeason;
    await game.settings.set("dimensional-weather", "settings", settings);

    const scene = game.scenes.viewed;
    if (scene?.id) {
      const savedState = scene.getFlag("dimensional-weather", "weatherState");
      if (savedState) {
        await scene.setFlag("dimensional-weather", "weatherState", {
          ...savedState,
          terrain: defaultTerrain,
          season: defaultSeason,
        });
      }
    }
  }

  /**
   * Fetches settings data for a campaign
   * @param {string} campaignId - The campaign ID
   * @returns {Promise<Object>} The settings data
   */
  async fetchSettingsData(campaignId) {
    try {
      const settingInfo = this.settingsIndex?.campaignSettings.find(
        (s) => s.id === campaignId
      );
      if (!settingInfo) {
        console.warn(
          `Dimensional Weather | No settings found for campaign ${campaignId}`
        );
        return null;
      }

      return await safeFetch(
        `/modules/dimensional-weather/campaign_settings/${settingInfo.path}`
      );
    } catch (error) {
      console.error(
        `Dimensional Weather | Failed to fetch settings for campaign ${campaignId}:`,
        error
      );
      return null;
    }
  }
}
